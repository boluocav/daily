<template>
	<view class="uni-product-list">
		<view class="uni-product" v-for="(product,index) in productList" :key="index" @click="popupShow=true">
			<view class="image-view">
				<image v-if="renderImage" class="uni-product-image" :src="product.image"></image>
			</view>
			<view class="uni-product-title">{{product.title}}</view>
			<view class="uni-product-price">
				<text class="uni-product-price-favour">￥{{product.originalPrice}}</text>
				<text class="uni-product-price-original">￥{{product.favourPrice}}</text>
				<text class="uni-product-tip">{{product.tip}}</text>
			</view>
		</view>
		<view class="sku">
			<echone-sku :show="popupShow" :combinations="combinations" :specifications="specifications"
				@close="handleClose" @confirm="handleConfirm"></echone-sku>
		</view>
	</view>
</template>

<script>
	import echoneSku from '@/components/echone-sku/echone-sku.vue'
	export default {
		components: {
			echoneSku,
		},
		data() {
			return {
				title: 'product-list',
				productList: [],
				renderImage: false,
				popupShow:false,
				//商品规格数组
				specifications: [{
						name: '颜色',
						id: '123',
						list: ['黑色', '白色'],
					},
					{
						name: '尺码',
						id: '456',
						list: ['S', 'M'],
					},
				],
				//商品规格笛卡尔积 2*2
				combinations: [{
						id: '1',
						value: '黑色,S',
						image: 'https://miniprogram-img01.caishuib.com/wx15168444f005a4ab/material/image/202005135/3a014c2f42c1c46b.PNG',
						price: 80.0,
						stock: 1000,
					},
					{
						id: '2',
						value: '黑色,M',
						image: 'https://miniprogram-img01.caishuib.com/wx15168444f005a4ab/material/image/20200383/ebd0c8d01a6e9c10.PNG',
						price: 100.0,
						stock: 500,
					},
					{
						id: '3',
						value: '白色,S',
						image: 'https://miniprogram-img01.caishuib.com/wx15168444f005a4ab/material/image/202005135/3a014c2f42c1c46b.PNG',
						price: 80.0,
						stock: 1000,
					},
					{
						id: '4',
						value: '白色,M',
						image: 'https://miniprogram-img01.caishuib.com/wx15168444f005a4ab/material/image/20200383/ebd0c8d01a6e9c10.PNG',
						price: 100.0,
						stock: 1000,
					},
				]
			};
		},
		methods: {
			handleClose() {
				this.popupShow=false;
			},
			handleConfirm(){
				uni.showToast({
					title:'购买成功',
					mask:true
				})
				this.popupShow=false;
			},
			loadData(action = 'add') {
				const data = [{
						image: 'https://img11.360buyimg.com/n7/jfs/t1/183280/2/14476/81709/60f27adbE2d9a155b/71828e374c91e0df.jpg',
						title: '蒙拓嘉 跆拳道护脚护手护脚套儿童护脚背散打训练专用护具全套护脚踝半指手套',
						originalPrice: 9999,
						favourPrice: 8888,
						tip: '自营'
					},
					{
						image: 'https://img14.360buyimg.com/n7/jfs/t5158/108/7539404/186360/606ffcf4/58f6f1ccN8e8e3d82.jpg',
						title: '竞派跆拳道脚靶训练器材成人儿童鸡腿靶手靶脚板脚红色2只',
						originalPrice: 3499,
						favourPrice: 3399,
						tip: '优惠'
					},
					{
						image: 'https://img12.360buyimg.com/n7/jfs/t1/201465/32/11107/58813/6163b8c8E580956ea/15b4567da1f6d519.jpg',
						title: '竞派道服跆拳道服成人儿童男女款初学跆拳道服装专业训练服 130码',
						originalPrice: 12999,
						favourPrice: 10688,
						tip: '秒杀'
					},
					{
						image: 'https://img12.360buyimg.com/n7/jfs/t1/174161/8/26070/140581/61da39a5E9a575ac2/01b4a7ba1053453e.jpg',
						title: '爱倍健（AIBEIJIAN）拳击手套 专业成人散打搏击比赛拳击套 儿童跆拳道训练手套',
						originalPrice: 999,
						favourPrice: 958,
						tip: '秒杀'
					},
					{
						image: 'https://img12.360buyimg.com/n7/jfs/t1/141098/17/20833/232290/617827b9E20eac2c2/1ab47e320095e831.jpg',
						title: '跆拳道道带跆拳道护具黑带天地仁绣字黑带刺绣道带空手道双节棍考级证书腰带定',
						originalPrice: 8888,
						favourPrice: 8288,
						tip: '优惠'
					},
					{
						image: 'https://img11.360buyimg.com/n7/jfs/t1/196961/35/16669/303189/618bedafE3f86584d/4face340cabf2a6f.jpg',
						title: '跟冠军学跆拳道 全彩图解视频学习版 跆拳道职业运动员郑姝音、吴静钰推荐',
						originalPrice: 2899,
						favourPrice: 2799,
						tip: '自营'
					}
				];

				if (action === 'refresh') {
					this.productList = [];
				}

				data.forEach(item => {
					this.productList.push(item);
				});
			}
		},
		onLoad() {
			this.loadData();
			setTimeout(() => {
				this.renderImage = true;
			}, 300);
		},
		onPullDownRefresh() {
			this.loadData('refresh');
			// 实际开发中通常是网络请求，加载完数据后就停止。这里仅做演示，加延迟为了体现出效果。
			setTimeout(() => {
				uni.stopPullDownRefresh();
			}, 2000);
		},
		// onReachBottom() {
		//     this.loadData();
		// }
	};
</script>

<style>
	/* product */
	page {
		background: #F8F8F8;
	}

	view {
		font-size: 28upx;
	}

	.uni-product-list {
		display: flex;
		width: 100%;
		flex-wrap: wrap;
		flex-direction: row;
	}

	.uni-product {
		padding: 20upx;
		display: flex;
		flex-direction: column;
	}

	.image-view {
		height: 330upx;
		width: 330upx;
		margin: 12upx 0;
	}

	.uni-product-image {
		height: 330upx;
		width: 330upx;
	}

	.uni-product-title {
		width: 300upx;
		word-break: break-all;
		display: -webkit-box;
		overflow: hidden;
		line-height: 1.5;
		text-overflow: ellipsis;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 2;
	}

	.uni-product-price {
		margin-top: 10upx;
		font-size: 28upx;
		line-height: 1.5;
		position: relative;
	}

	.uni-product-price-original {
		color: #e80080;
	}

	.uni-product-price-favour {
		color: #888888;
		text-decoration: line-through;
		margin-left: 10upx;
	}

	.uni-product-tip {
		position: absolute;
		right: 10upx;
		background-color: #ff3333;
		color: #ffffff;
		padding: 0 10upx;
		border-radius: 5upx;
	}
</style>
