<template>
	<view class="content">
		
		<view class="left">
			<view class="left-name">
				<span>红队名</span>
				<view @click="useOutClickSideRed">
					<easy-select :options="redOptions" @selectOne="selectOneRed" ref="easySelectRed" size="medium" :value="redName"></easy-select>
				</view>
				<!-- <u--input placeholder="A" border="none" inputAlign="center" color="#fff" v-model="redName"></u--input> -->
			</view>

			<view class="left-score">
				<span>{{redScore}}</span>
			</view>
			<view class="left-score-big">
				<span>{{redScore}}</span>
			</view>

			<view class="add-and-sub">
				<view class="left-add" @click="leftAdd">
					<span>＋</span>
				</view>
				<view class="left-add left-sub" @click="leftSub">
					<span>-</span>
				</view>
			</view>

			<view class="left-reset" @click="redScore=0">
				<span>重 置</span>
			</view>

		</view>

		<view class="vs">
			<span>VS</span>
		</view>

		<view class="count-down">
			<u-count-down ref="countDown" :time="time" format="HH:mm:ss" :autoStart="false" millisecond
				@change="onChange" @finish="finish">
				<view class="time">
					<view class="time__custom">
						<text
							class="time__custom__item">{{ timeData.hours>=10?timeData.hours:'0'+timeData.hours}}</text>
					</view>
					<text class="time__doc">:</text>
					<view class="time__custom">
						<text
							class="time__custom__item">{{ timeData.minutes>=10?timeData.minutes:'0'+timeData.minutes }}</text>
					</view>
					<text class="time__doc">:</text>
					<view class="time__custom">
						<text
							class="time__custom__item">{{ timeData.seconds>=10?timeData.seconds:'0'+timeData.seconds }}</text>
					</view>
				</view>
			</u-count-down>
		</view>

		<view class="start" @click="start">
			<span>比赛开始</span>
		</view>

		<view class="start" style="top: 580rpx;" @click="startOrpause">
			<span>{{tip}}</span>
		</view>

		<view class="start" style="top: 700rpx;" @click="over">
			<span>比赛结束</span>
		</view>

		<view class="start" style="top: 820rpx;" @click="navTo">
			<span>比赛记录</span>
		</view>

		<view class="start" style="top: 940rpx;" @click="reSet">
			<span>重新开始</span>
		</view>

		<view class="right">
			<view class="right-name">
				<span>蓝队名</span>
				
				<view @click="useOutClickSideBlue">
					<easy-select :options="blueOptions" @selectOne="selectOneBlue" ref="easySelectBlue" size="medium" :value="blueName"></easy-select>
				</view>
				<!-- <u--input placeholder="B" border="none" inputAlign="center" color="#fff" v-model="blueName"></u--input> -->
			</view>
			<view class="right-score">
				<span>{{blueScore}}</span>
			</view>
			<view class="right-score-big">
				<span>{{blueScore}}</span>
			</view>

			<view class="add-and-sub-righ">
				<view class="left-add" @click="rightAdd">
					<span>＋</span>
				</view>
				<view class="left-add left-sub" @click="rightSub">
					<span>-</span>
				</view>
			</view>

			<view class="add-and-sub-righ" @click="blueScore=0">
				<span class="left-reset">重 置</span>
			</view>

		</view>
	</view>
</template>

<script>
	import easySelect from '@/components/easy-select/easy-select.vue'
	export default {
		components: {
			easySelect
		},
		data() {
			return {
				redOptions:[{value:'1',label:'张三'},{value:'2',label:'李四'}],
				redName: 'A',
				blueOptions:[{value:'3',label:'王五'},{value:'4',label:'赵六'}],
				blueName: 'B',
				time: 60000,
				redScore: 0,
				blueScore: 0,
				timeData: {},
				isStart: false,
				tip: '计时开始',
				isCountDownOver: false
			}
		},
		onLoad() {},
		methods: {
			selectOneRed(options) {
				this.redName = options.label
			},
			useOutClickSideRed() {
				this.$refs.easySelectRed.hideOptions && this.$refs.easySelectRed.hideOptions()
			},
			useOutClickSideBlue() {
				this.$refs.easySelectBlue.hideOptions && this.$refs.easySelectBlue.hideOptions()
			},
			selectOneBlue(options) {
				this.blueName = options.label
			},
			navTo() {
				this.reSet();
				uni.navigateTo({
					url: '../record/record'
				})
			},
			overSetData() {
				//比赛结束后，把比分结果放入数据中  list[{redNameBlueName:[{第一局}，{第二局}],date:''}]
				let list = uni.getStorageSync('list');
				let key = this.redName + '_' + this.blueName;
				let date = uni.$u.timeFormat(new Date, 'yyyy-mm-dd hh:MM:ss');
				let redScore = this.redScore;
				let blueScore = this.blueScore;
				if (list) {
					let item = list.find(item => {
						return item.key == key;
					});
					if (item) {
						list.forEach(e => {
							if (e.key == key) {
								e.value.push({
									redScore,
									blueScore,
									date
								})
							}
						})
					} else {
						//这两个人第一次bitter
						list.unshift({
							key,
							value: [{
								redScore,
								blueScore,
								date
							}],
							date
						});
					}
					uni.setStorageSync('list', list);
				} else {
					//第一次比赛记录不存在
					let arrList = [];
					arrList.push({
						key,
						value: [{
							redScore,
							blueScore,
							date
						}],
						date
					})
					uni.setStorageSync('list', arrList);
				}
				this.reSet();
			},


			start() {
				if (this.redName == 'A' || this.blueName == 'B') {
					this.$u.toast('请输入双方名称');
					return;
				}
				this.isStart = true;
				this.tip = '暂停计时';
				this.$refs.countDown.start();
			},
			finish() {
				this.isStart = true;
				let that = this;
				//比赛结束
				uni.showModal({
					title: '提示',
					content: '比赛结束',
					showCancel: false,
					success: function(res) {
						if (res.confirm) {
							that.overSetData();
							uni.navigateTo({
								url: '../record/record'
							})
						}
					}
				});

			},
			over() {
				let that = this;
				if (!this.isStart) {
					return;
				}
				if (!this.isCountDownOver) {
					uni.showModal({
						title: '提示',
						content: '是否提前结束比赛',
						success: function(res) {
							if (res.confirm) {
								//提前结束比赛
								that.overSetData();
								uni.navigateTo({
									url: '../record/record'
								})
							} else if (res.cancel) {}
						}
					});
				}
			},
			startOrpause() {
				if (!this.isStart) {
					this.$u.toast('请先开始比赛');
					return;
				}
				if (this.tip == '计时开始') {
					this.tip = '暂停计时'
					this.$refs.countDown.start();
				} else {
					this.tip = '计时开始'
					this.$refs.countDown.pause();
				}
			},
			reSet() {
				this.isStart = false;
				this.redScore = 0;
				this.blueScore = 0;
				this.tip = '计时开始';
				this.$refs.countDown.reset();
			},
			leftAdd() {
				if (!this.isStart) {
					this.$u.toast('请先开始比赛');
					return;
				}
				this.redScore++;
			},
			leftSub() {
				if (!this.isStart) {
					this.$u.toast('请先开始比赛');
					return;
				}
				this.redScore == 0 ? '' : this.redScore--;
			},

			onChange(e) {
				this.timeData = e
			},

			rightAdd() {
				if (!this.isStart) {
					this.$u.toast('请先开始比赛');
					return;
				}
				this.blueScore++;
			},
			rightSub() {
				if (!this.isStart) {
					this.$u.toast('请先开始比赛');
					return;
				}
				this.blueScore == 0 ? '' : this.blueScore--;
			}
		}
	}
</script>

<style scoped lang="scss">
	.content {
		display: flex;
		align-items: center;
		justify-content: space-around;
	}
	.redSelect{
		position: absolute;
		// padding: 30rpx;
	}

	.left {
		width: 100%;
		height: 100vh;
		background-color: red;
	}

	.left-name {
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		margin: 60rpx 60rpx 0 20rpx;
		padding: 20rpx 50rpx;
		background-color: #000;
		color: #fff;
	}

	.left-score {
		width: 150rpx;
		height: 150rpx;
		text-align: center;
		line-height: 150rpx;
		background-color: #000;
		color: red;
		font-size: xx-large;
		margin: 60rpx 0 0 100rpx;
	}

	.left-score-big {
		width: 250rpx;
		height: 250rpx;
		text-align: center;
		line-height: 250rpx;
		background-color: #000;
		color: #fff;
		font-size: 200rpx;
		margin-top: 50rpx;
	}

	.add-and-sub {
		display: flex;
		justify-content: flex-start;
		align-items: center;
	}

	.left-add {
		width: 100rpx;
		height: 100rpx;
		text-align: center;
		line-height: 100rpx;
		background-color: #000;
		color: #fff;
		font-size: x-large;
		margin-top: 80rpx;
	}

	.left-sub {
		margin-top: 80rpx;
		margin-left: 50rpx;
	}

	.left-reset {
		width: 250rpx;
		height: 100rpx;
		background-color: #000;
		color: #fff;
		text-align: center;
		line-height: 100rpx;
		margin-top: 20rpx;
	}

	.vs {
		position: absolute;
		top: 80rpx;
		width: 100rpx;
		height: 100rpx;
		border-radius: 50rpx;
		text-align: center;
		line-height: 100rpx;
		color: #fff;
		background-color: purple;
	}

	.start {
		position: absolute;
		top: 460rpx;
		width: 180rpx;
		height: 100rpx;
		text-align: center;
		line-height: 100rpx;
		color: #fff;
		background-color: #000;
	}

	.count-down {
		position: absolute;
		top: 280rpx;
		background-color: #000;
		padding: 20rpx;
	}

	.time {
		@include flex;
		align-items: center;

		&__custom {
			/* #ifndef APP-NVUE */
			display: flex;
			/* #endif */
			justify-content: center;
			align-items: center;

			&__item {
				color: #fff;
				font-size: 20px;
				text-align: center;
			}
		}

		&__doc {
			color: #fff;
		}
	}

	.right {
		width: 100%;
		height: 100vh;
		background-color: blue;
	}

	.right-name {
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		margin: 60rpx 20rpx 0 60rpx;
		padding: 20rpx 50rpx;
		background-color: #000;
		color: #fff;
	}

	.right-score {
		width: 150rpx;
		height: 150rpx;
		text-align: center;
		line-height: 150rpx;
		background-color: #000;
		color: blue;
		font-size: xx-large;
		margin: 60rpx 0 0 130rpx;
	}

	.right-score-big {
		width: 250rpx;
		height: 250rpx;
		text-align: center;
		line-height: 250rpx;
		background-color: #000;
		color: #fff;
		font-size: 200rpx;
		margin: 50rpx 0 0 130rpx;
	}

	.add-and-sub-righ {
		display: flex;
		justify-content: flex-end;
		align-items: center;
	}
</style>
