<template>
	<view class="content">
		<view class="title">
			<u-avatar :src="userInfo.avatarUrl" size="60"></u-avatar>
			<p>{{userInfo.nickName}}</p>
		</view>
		<view class="cell">
			<u-cell-group :border="false">
				<u-cell title="我的预约" isLink url="/pages/way/list"></u-cell>
				<!-- <u-cell title="我的购物" isLink url="/pages/car/car"></u-cell> -->
				<u-cell title="在线计分" isLink url="/pages/integral/integral"></u-cell>
				<u-cell title="比赛记录" isLink url="/pages/record/record"></u-cell>
				<u-cell title="配送服务" isLink></u-cell>
				<u-cell title="电话咨询" isLink :border="false"></u-cell>
			</u-cell-group>
		</view>
		<view style="padding: 10rpx 30rpx">
			<u-button @click="logout" type="primary" text="退出登陆"></u-button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				userInfo: {}
			}
		},

		onLoad() {
			this.userInfo = uni.getStorageSync('userInfo');
		},
		methods: {
			logout() {
				uni.showModal({
					title: '提示',
					content: '是否确定退出',
					success: function(res) {
						if (res.confirm) {
							uni.removeStorageSync('userInfo');
							uni.reLaunch({
								url:'../login/login'
							})
						} else if (res.cancel) {
							console.log('用户点击取消');
						}
					}

				})
			}
		}
	}
</script>

<style lang="scss">
	page {
		background-color: #F0F0F0;
	}

	.title {
		display: flex;
		justify-content: flex-start;
		align-items: center;
		padding: 50rpx;
		margin: 30rpx;
		border-radius: 20rpx;
		background-color: #0481DE;

		p {
			color: #fff;
			margin-left: 20rpx;
		}
	}

	.cell {
		border-radius: 20rpx;
		background-color: #fff;
		margin-top: 20rpx;
		margin: 30rpx;
	}
</style>
