<template>
	<view class="content">
		<u-empty v-if="list.length==0" text="暂无记录~~~" mode="data" icon="http://cdn.uviewui.com/uview/empty/data.png">
		</u-empty>
		<view class="list" v-for="item in list" :key="item.key">

			<view class="delete" @click="deleteItem(item)">
				<u-icon name="close" color="red" size="22"></u-icon>
			</view>

			<view class="card">
				<view class="title">
					<view v-if="calculateScore(item.value).red>calculateScore(item.value).blue">
						<span style="color: red;">{{item.key.substring(0,item.key.indexOf('_'))}}</span>胜
					</view>
					<view v-else-if="calculateScore(item.value).red<calculateScore(item.value).blue">
						<span style="color: blue;">{{item.key.substring(item.key.indexOf('_')+1)}}</span>胜
					</view>
					<view v-else>
						<span>平局</span>
					</view>
				</view>
				<span style="margin-top: 20rpx;">{{item.date}}</span>
				<view class="center">
					<span style="color: red;font-size: larger;">{{item.key.substring(0,item.key.indexOf('_'))}}</span>
					<view class="vs">VS</view>
					<span style="color: blue;font-size: larger;">{{item.key.substring(item.key.indexOf('_')+1)}}</span>
				</view>

				<view class="center">
					<span style="color: red;font-size: x-large;">{{calculateScore(item.value).red}}</span>
					<span style="font-size: x-large;">:</span>
					<span style="color: blue;font-size: x-large;">{{calculateScore(item.value).blue}}</span>
				</view>

			</view>
			<view class="item-list" v-for="(itemDetail,index) in item.value" :key="index">
				<u-gap height="2" bgColor="#cdcdcd"></u-gap>
				<view class="card detail">
					<span style="font-size: x-small;font-weight: bold;">第{{index+1}}局</span>
					<view class="detail-score">
						<view style="color: red;">{{itemDetail.redScore}}</view>
						<view style="color: blue;">{{itemDetail.blueScore}}</view>
					</view>
					<span style="font-size: small;">{{itemDetail.date}}</span>
				</view>
			</view>

			<u-gap height="10" bgColor="#cdcdcd"></u-gap>
		</view>
	</view>
</template>

<script>
	export default {
		onShow() {
			this.list = uni.getStorageSync('list');
		},
		data() {
			return {
				list: []
			}
		},
		methods: {
			deleteItem(item) {
				let that = this;
				uni.showModal({
					title: '提示',
					content: '是否确认删除？',
					success: function(res) {
						if (res.confirm) {
							that.list.splice(that.list.findIndex(e => e.key == item.key), 1);
							uni.setStorageSync('list', that.list);
							that.$u.toast('删除成功');
						}
					}
				});
			},
			//计算总比分
			calculateScore(list) {
				let red = 0;
				let blue = 0;
				list.forEach(item => {
					if (item.blueScore > item.redScore) {
						blue++;
					}
					if (item.blueScore < item.redScore) {
						red++;
					}
				})
				return {
					red,
					blue
				};
			}
		}
	}
</script>

<style scoped lang="scss">
	.card {
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		padding: 20rpx;
	}

	.delete {
		display: flex;
		justify-content: flex-end;
		margin-top: 20rpx;
		margin-right: 20rpx;

	}

	.title {
		font-size: xx-large;
	}

	.center {
		display: flex;
		justify-content: center;
		align-items: center;
	}

	.vs {
		width: 80rpx;
		height: 80rpx;
		border-radius: 40rpx;
		text-align: center;
		line-height: 80rpx;
		color: #fff;
		background-color: purple;
		margin: 20rpx 30rpx;
	}

	.detail {
		padding: 20rpx 50rpx;
		// border: 1rpx solid red;
	}

	.detail-score {
		width: 100%;
		display: flex;
		justify-content: space-between;
		align-items: center;
	}
</style>
