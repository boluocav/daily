<template>
	<view class="content">
		<view class="swiper">
			<u-swiper :list="list" indicator indicatorMode="line" circular></u-swiper>
		</view>
		<view class="cell">
			<u-cell-group>
				<u-cell title="课程简介" :border="false">
					<i slot="icon" class="iconfont" style="color: red; font-size: 50rpx;">&#xe601;</i>
				</u-cell>
			</u-cell-group>
		</view>

		<view class="grid">
			<u-grid col="2" align="center">
				<u-grid-item :customStyle="{padding:'0 0 20rpx 25rpx'}">
					<image style="width: 300rpx; height: 380rpx;"
						src="https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fimg.zcool.cn%2Fcommunity%2F0194ae5eef1c46a801215aa09f1393.jpg%401280w_1l_2o_100sh.jpg&refer=http%3A%2F%2Fimg.zcool.cn&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1644570569&t=8372c0856624d1c1e77916a33deda1ea">
					</image>
				</u-grid-item>
				<u-grid-item :customStyle="{padding:'0 25rpx 20rpx 0'}">
					<image style="width: 300rpx; height: 380rpx;"
						src="https://img1.baidu.com/it/u=2835131881,1389686403&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=889">
					</image>
				</u-grid-item>
				<u-grid-item :customStyle="{padding:'0 0 20rpx 25rpx'}">
					<image style="width: 300rpx; height: 380rpx;"
						src="https://img1.baidu.com/it/u=2334967167,1476704443&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=333">
					</image>
				</u-grid-item>
				<u-grid-item :customStyle="{padding:'0 25rpx 20rpx 0'}">
					<image style="width: 300rpx; height: 380rpx;"
						src="https://img1.baidu.com/it/u=1384870897,674268706&fm=253&fmt=auto&app=138&f=JPEG?w=646&h=500">
					</image>
				</u-grid-item>
			</u-grid>
		</view>

		<view class="cell">
			<u-cell-group>
				<u-cell title="视频简介" :border="false">
					<i slot="icon" class="iconfont" style="color: red; font-size: 50rpx;">&#xe601;</i>
				</u-cell>
			</u-cell-group>
		</view>
		<view class="vo">
			<video class="video" enable-play-gesture
				src="https://baikevideo.cdn.bcebos.com/media/mda-XzjFOML8EqV0UmyK/1ee39ce23031e7a382d4fa58b811f96b.mp4">
			</video>
		</view>

	</view>
</template>

<script>
	export default {
		onLoad() {
			let userInfo = uni.getStorageSync('userInfo');
			console.log(userInfo);
			if (!userInfo) {
				uni.redirectTo({
					url: '../login/login'
				})
			}
		},
		data() {
			return {
				list: [
					'https://cdn.uviewui.com/uview/swiper/swiper3.png',
					'https://cdn.uviewui.com/uview/swiper/swiper2.png',
					'https://cdn.uviewui.com/uview/swiper/swiper1.png',
				],
			}
		},
		methods: {}
	}
</script>

<style scoped lang="scss">
	.content {
		padding: 20rpx;
	}

	.cell {
		margin-top: 20rpx;
	}

	.vo {
		display: flex;
		justify-content: center;
		align-items: center;
	}
</style>
