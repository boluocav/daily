<template>
	<view class="content">
		<view class="logo">
			<u--image shape="circle" :showLoading="true" src='https://cdn.uviewui.com/uview/album/1.jpg' width="80px" height="80px" @click="click"></u--image>
			<!-- <image style="width: 500rpx; height: auto;" src="../../static/logo.png" mode="widthFix"></image> -->
		</view>
		<view class="login" style="padding: 30px ; ">
			<u-button @click="toLogin" type="primary" text="登陆"></u-button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {};
		},
		methods: {
			toLogin() {
				let that = this;
				uni.getUserProfile({
					desc: '登陆获取用户信息',
					success(res) {
						//异步调用 登陆 获取到openid
						uni.login({
							provider: 'weixin',
							success: function(loginRes) {
								uni.setStorageSync('userInfo',res.userInfo);
								uni.switchTab({
									url:'../index/index'
								})
							}
						});
					},
					fail(res) {
						console.log(res);
					}
				})
			}
		}
	}
</script>

<style lang="scss">
	page {
		background-color: #F0F0F0;
	}
	.logo{
		display: flex;
		justify-content: center;
		align-items: center;
		margin-top: 50rpx;
	}
</style>
